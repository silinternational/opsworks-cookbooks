name        "opsworks_nodejs"
description 'Installs and configures a Node.js application server'
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends 'deploy'
depends 'opsworks_commons'
