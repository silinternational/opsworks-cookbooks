require 'minitest/spec'

describe_recipe 'opsworks_custom_cookbooks::update' do
  include MiniTest::Chef::Resources
  include MiniTest::Chef::Assertions

end
