name 'mysql_replication_test'
version '0.0.1'

depends 'mysql'
