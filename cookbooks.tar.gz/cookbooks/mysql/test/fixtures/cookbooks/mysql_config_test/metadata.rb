name 'mysql_config_test'
version '0.0.1'

depends 'mysql'
