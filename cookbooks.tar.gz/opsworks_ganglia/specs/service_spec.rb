#
# This is tested on specs/server_spec.rb
#
